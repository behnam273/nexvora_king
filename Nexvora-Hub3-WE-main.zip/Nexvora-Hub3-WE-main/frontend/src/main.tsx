import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Register safe PWA service worker (caches static shell only, never API/auth data)
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // Service worker registration is optional
    });
  });
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
