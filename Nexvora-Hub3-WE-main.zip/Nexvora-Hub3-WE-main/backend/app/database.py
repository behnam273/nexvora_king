from __future__ import annotations

from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings


class Base(DeclarativeBase):
    pass


def normalize_database_url(raw_url: str) -> str:
    """Normalize Railway/Supabase postgres:// or postgresql+psycopg:// URLs for SQLAlchemy 2.x + psycopg2."""
    url = raw_url.strip()
    if url.startswith("postgres://"):
        return "postgresql+psycopg2://" + url[len("postgres://"):]
    if url.startswith("postgresql+psycopg://"):
        return "postgresql+psycopg2://" + url[len("postgresql+psycopg://"):]
    if url.startswith("postgresql://"):
        return "postgresql+psycopg2://" + url[len("postgresql://"):]
    return url


def _register_numpy_psycopg2_adapters() -> None:
    """Register NumPy scalar adapters for psycopg2 so PostgreSQL never fails on np.float64/np.int64/np.bool_."""
    try:
        import numpy as np
        from psycopg2.extensions import AsIs, register_adapter

        for np_float in (np.float16, np.float32, np.float64):
            register_adapter(np_float, lambda x: AsIs(repr(float(x))))
        for np_int in (np.int8, np.int16, np.int32, np.int64, np.uint8, np.uint16, np.uint32, np.uint64):
            register_adapter(np_int, lambda x: AsIs(int(x)))
        register_adapter(np.bool_, lambda x: AsIs(bool(x)))
    except Exception:
        pass


def _build_engine():
    _register_numpy_psycopg2_adapters()
    settings = get_settings()
    db_url = normalize_database_url(settings.database_url)
    is_sqlite = db_url.startswith("sqlite")

    engine_kwargs = {
        "pool_pre_ping": True,
        "future": True,
    }
    if is_sqlite:
        engine_kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
    else:
        # Production PostgreSQL pool tuning (Railway / Supabase)
        engine_kwargs["pool_size"] = 5
        engine_kwargs["max_overflow"] = 10
        engine_kwargs["pool_recycle"] = 300
        engine_kwargs["connect_args"] = {"connect_timeout": 10}

    eng = create_engine(db_url, **engine_kwargs)
    if is_sqlite:
        @event.listens_for(eng, "connect")
        def _set_sqlite_pragma(dbapi_connection, _connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON;")
            cursor.execute("PRAGMA journal_mode=WAL;")
            cursor.close()
    return eng


engine = _build_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    import time
    from app import models  # noqa: F401

    last_err: Exception | None = None
    for attempt in range(5):
        try:
            Base.metadata.create_all(bind=engine)
            return
        except Exception as exc:
            last_err = exc
            if attempt < 4:
                time.sleep(1.5 * (attempt + 1))
    if last_err is not None:
        raise last_err
