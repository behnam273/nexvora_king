from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import numpy as np

from app.config import SYMBOL_META, TIMEFRAME_META
from app.engine.market_data import Candle


@dataclass
class HighAccuracyParams:
    """Parameters uniting hub3.txt core execution with High Accuracy strict filters & 1.2R/2.2R/3.2R targets."""
    tp1_rr: float = 1.2
    tp2_rr: float = 2.2
    tp3_rr: float = 3.2
    tp1_exit_pct: float = 50.0
    tp2_exit_pct: float = 30.0

    min_score_4h: float = 8.0
    min_score_15m: float = 8.0
    min_score_5m: float = 8.5
    min_adx: float = 25.0
    trend_ema_len: int = 200
    require_sweep: bool = True
    require_idm: bool = True
    require_strong_choch_body: bool = True
    use_pd_filter: bool = True
    use_session_filter: bool = True
    skip_dead_volatility: bool = True
    skip_news_spikes: bool = True
    risk_pct: float = 1.0
    account_equity_ref: float = 10000.0

    # Strict constants aligned with hub3.txt + dis.zip High Accuracy table
    disp_atr_mult: float = 1.0
    poi_dist_atr: float = 0.20
    fvg_min_atr: float = 0.22
    ob_lookback: int = 20
    ifc_mult: float = 1.8
    eq_tol_atr: float = 0.15
    sl_buf_atr: float = 0.30
    min_risk_atr: float = 1.2
    min_stop_pips: float = 3.0
    spike_mult: float = 2.5
    vol_min_ratio: float = 0.70
    pd_len: int = 18


@dataclass
class LiquidityLevel:
    price: float
    kind: int          # +1 = buy-side (high), -1 = sell-side (low)
    used: bool = False
    is_equal: bool = False
    bar_idx: int = 0


@dataclass
class POIZone:
    top: float
    bot: float
    direction: int     # +1 bull, -1 bear
    poi_type: int      # 1=FVG, 2=OB, 3=SCOB, 4=FLIP, 5=IFC
    bar_idx: int
    quality: float


@dataclass
class TradeSetupSignal:
    bar_idx: int
    timestamp: datetime
    symbol: str
    timeframe: str
    risk_tier: str
    direction: str          # LONG | SHORT
    entry_module: str       # CHoCH | SWEEP | FLIP | OB | FVG | SCOB | IFC
    entry_price: float
    sl: float
    tp1: float
    tp2: float
    tp3: float
    tp1_exit_pct: float
    tp2_exit_pct: float
    tp3_exit_pct: float
    confluence_score: float
    grade: str              # A+ | A | B
    htf_bias: str           # BULLISH | BEARISH | NEUTRAL
    session_name: str
    position_size_lots: float
    checklist: List[dict]
    rationale_fa: str
    bars_valid: int


@dataclass
class EngineEvaluation:
    symbol: str
    timeframe: str
    risk_tier: str
    state: str              # FLAT | ARMED | SETUP_READY
    htf_bias: str
    session_name: str
    adx_value: float
    atr_value: float
    readiness_pct: int
    why_no_trade_fa: str
    active_poi_count: int
    active_liq_count: int
    latest_signal: Optional[TradeSetupSignal] = None
    historical_signals: List[TradeSetupSignal] = field(default_factory=list)


# -------------------- Technical Indicators --------------------

def compute_ema(values: np.ndarray, length: int) -> np.ndarray:
    n = len(values)
    out = np.full(n, np.nan, dtype=np.float64)
    if n == 0 or length <= 0:
        return out
    alpha = 2.0 / (length + 1.0)
    out[0] = values[0]
    for i in range(1, n):
        out[i] = alpha * values[i] + (1.0 - alpha) * out[i - 1]
    return out


def compute_rma(values: np.ndarray, length: int) -> np.ndarray:
    n = len(values)
    out = np.full(n, np.nan, dtype=np.float64)
    if n < length or length <= 0:
        return out
    out[length - 1] = float(np.mean(values[:length]))
    alpha = 1.0 / length
    for i in range(length, n):
        out[i] = alpha * values[i] + (1.0 - alpha) * out[i - 1]
    return out


def compute_atr(highs: np.ndarray, lows: np.ndarray, closes: np.ndarray, length: int = 14) -> np.ndarray:
    n = len(closes)
    tr = np.zeros(n, dtype=np.float64)
    tr[0] = highs[0] - lows[0]
    for i in range(1, n):
        tr[i] = max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        )
    atr = compute_rma(tr, length)
    # Fill early bars with simple average so indicator never breaks
    for i in range(min(length - 1, n)):
        atr[i] = float(np.mean(tr[: i + 1]))
    return atr


def compute_sma(values: np.ndarray, length: int) -> np.ndarray:
    n = len(values)
    out = np.full(n, np.nan, dtype=np.float64)
    for i in range(n):
        start = max(0, i - length + 1)
        window = values[start : i + 1]
        valid = window[~np.isnan(window)]
        if len(valid) > 0:
            out[i] = float(np.mean(valid))
    return out


def compute_adx(highs: np.ndarray, lows: np.ndarray, closes: np.ndarray, length: int = 14) -> np.ndarray:
    n = len(closes)
    if n < length + 2:
        return np.full(n, 25.0, dtype=np.float64)
    up_move = np.zeros(n, dtype=np.float64)
    dn_move = np.zeros(n, dtype=np.float64)
    tr = np.zeros(n, dtype=np.float64)
    tr[0] = highs[0] - lows[0]
    for i in range(1, n):
        up = highs[i] - highs[i - 1]
        dn = lows[i - 1] - lows[i]
        up_move[i] = up if (up > dn and up > 0) else 0.0
        dn_move[i] = dn if (dn > up and dn > 0) else 0.0
        tr[i] = max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        )
    atr = compute_rma(tr, length)
    plus_dm = compute_rma(up_move, length)
    minus_dm = compute_rma(dn_move, length)

    dx = np.zeros(n, dtype=np.float64)
    for i in range(length, n):
        if np.isnan(atr[i]) or atr[i] <= 0:
            continue
        pdi = 100.0 * plus_dm[i] / atr[i]
        mdi = 100.0 * minus_dm[i] / atr[i]
        denom = pdi + mdi
        dx[i] = (100.0 * abs(pdi - mdi) / denom) if denom > 0 else 0.0
    adx = compute_rma(dx, length)
    for i in range(n):
        if np.isnan(adx[i]):
            adx[i] = 25.0
    return adx


def classify_session_ny(ts_utc: datetime) -> Tuple[str, bool, bool, bool]:
    """
    Classify trading session according to hub3.txt America/New_York windows:
    Asia: 20:00-23:59 NY, London: 02:00-05:00 NY, NY AM: 07:00-10:00 NY, NY PM: 13:30-16:00 NY.
    Uses standard UTC-5 offset (NY EST) as deterministic approximation.
    Returns (session_name, in_active_kz, in_asia, in_london).
    """
    utc = ts_utc.astimezone(timezone.utc)
    ny_hour = (utc.hour - 5) % 24
    ny_min = utc.minute
    hm = ny_hour * 60 + ny_min

    in_asia = 20 * 60 <= hm <= 23 * 60 + 59
    in_london = 2 * 60 <= hm <= 7 * 60
    in_ny_am = 7 * 60 < hm <= 11 * 60 + 30
    in_ny_pm = 11 * 60 + 30 < hm <= 16 * 60
    # Active institutional window: London Open through NY PM (02:00 - 16:00 NY)
    in_active = in_london or in_ny_am or in_ny_pm
    if in_london:
        name = "LONDON"
    elif in_ny_am:
        name = "NEW YORK AM"
    elif in_ny_pm:
        name = "NEW YORK PM"
    elif in_asia:
        name = "ASIA"
    else:
        name = "OFF-SESSION"
    return name, in_active, in_asia, in_london


def compute_htf_bias_from_candles(htf_candles: Optional[List[Candle]], ema_len: int = 50) -> int:
    if not htf_candles or len(htf_candles) < 15:
        return 0
    closes = np.array([c.close for c in htf_candles], dtype=np.float64)
    ema = compute_ema(closes, min(ema_len, len(closes) - 1))
    if closes[-1] > ema[-1]:
        return 1
    if closes[-1] < ema[-1]:
        return -1
    return 0


def _score_to_grade(score: float) -> str:
    if score >= 9.0:
        return "A+"
    if score >= 8.0:
        return "A"
    if score >= 7.0:
        return "B"
    return "C"


def _compute_lot_size(symbol: str, entry: float, sl: float, risk_pct: float, equity: float) -> float:
    meta = SYMBOL_META[symbol]
    dist = abs(entry - sl)
    if dist <= 0:
        return 0.01
    risk_money = equity * (risk_pct / 100.0)
    # Approximate USD per 1 standard lot per 1.0 price unit
    if symbol == "XAUUSD":
        usd_per_unit_per_lot = 100.0
    elif symbol.endswith("USD"):
        usd_per_unit_per_lot = 100000.0
    elif symbol == "USDJPY":
        usd_per_unit_per_lot = 100000.0 / max(entry, 1.0)
    else:  # EURGBP (quoted in GBP; approximate GBPUSD ~ 1.27)
        usd_per_unit_per_lot = 100000.0 * 1.27
    lots = risk_money / (dist * usd_per_unit_per_lot)
    return round(max(0.01, min(lots, 50.0)), 2)


def run_trading_hub3_engine(
    symbol: str,
    timeframe: str,
    candles: List[Candle],
    params: Optional[HighAccuracyParams] = None,
    htf1_candles: Optional[List[Candle]] = None,
    htf2_candles: Optional[List[Candle]] = None,
    news_blackout_active: bool = False,
) -> EngineEvaluation:
    """
    Faithful Python implementation of hub3.txt (Trading Hub 3.0 SMC Engine)
    augmented with the High Accuracy strict quality filter gate from dis.zip.
    Produces all verified historical setups across the candle series plus the
    exact real-time state machine snapshot on the latest closed candle.
    """
    params = params or HighAccuracyParams()
    meta = SYMBOL_META[symbol]
    tf_meta = TIMEFRAME_META[timeframe]
    digits = meta["digits"]
    pip_size = meta["pip_size"]
    risk_tier = tf_meta["risk_tier"]

    n = len(candles)
    if n < 80:
        return EngineEvaluation(
            symbol=symbol,
            timeframe=timeframe,
            risk_tier=risk_tier,
            state="FLAT",
            htf_bias="NEUTRAL",
            session_name="OFF-SESSION",
            adx_value=0.0,
            atr_value=0.0,
            readiness_pct=0,
            why_no_trade_fa="داده کندلی کافی برای ارزیابی Trading Hub 3.0 وجود ندارد.",
            active_poi_count=0,
            active_liq_count=0,
        )

    opens = np.array([c.open for c in candles], dtype=np.float64)
    highs = np.array([c.high for c in candles], dtype=np.float64)
    lows = np.array([c.low for c in candles], dtype=np.float64)
    closes = np.array([c.close for c in candles], dtype=np.float64)

    atr_arr = compute_atr(highs, lows, closes, 14)
    atr_sma50 = compute_sma(atr_arr, 50)
    adx_arr = compute_adx(highs, lows, closes, 14)
    ema_trend = compute_ema(closes, min(params.trend_ema_len, max(20, n // 2)))
    ema_htf_proxy = compute_ema(closes, 50)

    # Higher-timeframe bias from actual HTF candles when provided
    htf1_bias_global = compute_htf_bias_from_candles(htf1_candles, 50)
    htf2_bias_global = compute_htf_bias_from_candles(htf2_candles, 50)

    pivot_len = tf_meta["pivot_len"]
    minor_len = 2
    cooldown_bars = tf_meta["cooldown_bars"]
    arm_valid_bars = tf_meta["arm_valid_bars"]
    tf_min_score = (
        params.min_score_4h if timeframe == "4H"
        else params.min_score_15m if timeframe == "15m"
        else params.min_score_5m
    )
    use_session_tf = params.use_session_filter and tf_meta["require_session_filter"]

    # State arrays matching hub3.txt
    liq_levels: List[LiquidityLevel] = []
    poi_zones: List[POIZone] = []
    max_liq = 18
    max_poi = 12

    last_ph: Optional[float] = None
    last_pl: Optional[float] = None
    minor_ph: Optional[float] = None
    minor_pl: Optional[float] = None
    idm_done = False

    day_id: Optional[int] = None
    asia_h: Optional[float] = None
    asia_l: Optional[float] = None
    was_asia = False
    ldn_h: Optional[float] = None
    ldn_l: Optional[float] = None
    was_london = False

    arm_dir = 0
    arm_bar = -999
    arm_price = 0.0
    arm_struct = 0.0
    arm_eq = False
    arm_swept = False
    last_signal_bar = -999

    signals: List[TradeSetupSignal] = []
    last_why_fa = "در انتظار سوییپ نقدینگی معتبر..."

    def find_near_liq(px: float, kind: int, tol: float) -> int:
        for idx, lv in enumerate(liq_levels):
            if lv.kind == kind and abs(lv.price - px) <= tol:
                return idx
        return -1

    def liq_target(from_px: float, direction: int, min_dist: float) -> Optional[float]:
        best: Optional[float] = None
        for lv in liq_levels:
            if not lv.used and lv.kind == (1 if direction > 0 else -1):
                d = (lv.price - from_px) * direction
                if d >= min_dist:
                    if best is None or d < (best - from_px) * direction:
                        best = lv.price
        return best

    def add_liq(px: float, kind: int, bar_idx: int, tol: float) -> None:
        near = find_near_liq(px, kind, tol)
        if near >= 0:
            liq_levels[near].is_equal = True
            return
        if len(liq_levels) >= max_liq:
            liq_levels.pop(0)
        liq_levels.append(LiquidityLevel(price=px, kind=kind, bar_idx=bar_idx))

    def add_poi(top: float, bot: float, direction: int, poi_type: int, quality: float, bar_idx: int) -> None:
        if len(poi_zones) >= max_poi:
            poi_zones.pop(0)
        poi_zones.append(POIZone(top=top, bot=bot, direction=direction, poi_type=poi_type, bar_idx=bar_idx, quality=quality))

    def pick_poi(direction: int, since_bar: int, close_px: float, atr_val: float) -> Optional[POIZone]:
        for z in reversed(poi_zones):
            if z.direction == direction and z.bar_idx >= since_bar - 4:
                mid = (z.top + z.bot) / 2.0
                if direction == 1 and mid < close_px - params.poi_dist_atr * atr_val:
                    return z
                if direction == -1 and mid > close_px + params.poi_dist_atr * atr_val:
                    return z
        return None

    for i in range(max(22, pivot_len * 2 + 1), n):
        c = candles[i]
        o, h, l, cl = opens[i], highs[i], lows[i], closes[i]
        atr = atr_arr[i] if atr_arr[i] > 0 else pip_size * 10
        adx = adx_arr[i]
        ses_name, in_session, in_asia, in_london = classify_session_ny(c.timestamp)

        # Bar-local HTF bias (uses global HTF candles for recent bars, EMA50 slope fallback historically)
        if i >= n - 45 and htf1_bias_global != 0:
            htf_bias = htf1_bias_global
        else:
            htf_bias = 1 if cl > ema_htf_proxy[i] else -1 if cl < ema_htf_proxy[i] else 0

        if i >= n - 45 and htf2_bias_global != 0:
            htf2_bias = htf2_bias_global
        else:
            htf2_bias = 1 if cl > ema_trend[i] else -1 if cl < ema_trend[i] else 0

        # 1. Daily & session liquidity (hub3.txt Section 1)
        cur_day = c.timestamp.day
        if day_id is None or cur_day != day_id:
            if i > 0:
                add_liq(highs[i - 1], 1, i - 1, params.eq_tol_atr * atr)
                add_liq(lows[i - 1], -1, i - 1, params.eq_tol_atr * atr)
            day_id = cur_day
        if in_asia:
            asia_h = h if asia_h is None else max(asia_h, h)
            asia_l = l if asia_l is None else min(asia_l, l)
            was_asia = True
        elif was_asia:
            if asia_h is not None:
                add_liq(asia_h, 1, i, params.eq_tol_atr * atr)
            if asia_l is not None:
                add_liq(asia_l, -1, i, params.eq_tol_atr * atr)
            asia_h = asia_l = None
            was_asia = False
        if in_london:
            ldn_h = h if ldn_h is None else max(ldn_h, h)
            ldn_l = l if ldn_l is None else min(ldn_l, l)
            was_london = True
        elif was_london:
            if ldn_h is not None:
                add_liq(ldn_h, 1, i, params.eq_tol_atr * atr)
            if ldn_l is not None:
                add_liq(ldn_l, -1, i, params.eq_tol_atr * atr)
            ldn_h = ldn_l = None
            was_london = False

        # 2. Confirmed Pivot High / Low (strictly non-repaint: center = i - pivot_len)
        pc = i - pivot_len
        if pc >= pivot_len:
            win_h = highs[pc - pivot_len : pc + pivot_len + 1]
            win_l = lows[pc - pivot_len : pc + pivot_len + 1]
            if highs[pc] == np.max(win_h):
                last_ph = float(highs[pc])
                add_liq(last_ph, 1, pc, params.eq_tol_atr * atr)
            if lows[pc] == np.min(win_l):
                last_pl = float(lows[pc])
                add_liq(last_pl, -1, pc, params.eq_tol_atr * atr)

        mc = i - minor_len
        if mc >= minor_len:
            mwin_h = highs[mc - minor_len : mc + minor_len + 1]
            mwin_l = lows[mc - minor_len : mc + minor_len + 1]
            if highs[mc] == np.max(mwin_h):
                minor_ph = float(highs[mc])
            if lows[mc] == np.min(mwin_l):
                minor_pl = float(lows[mc])

        hi20 = float(np.max(highs[i - 20 : i]))
        lo20 = float(np.min(lows[i - 20 : i]))

        # 3. POI detection: FVG, OB, SCOB, IFC (hub3.txt Sections 3-5)
        body = abs(cl - o)
        strong = body >= params.disp_atr_mult * atr
        if strong and l > highs[i - 2] and (l - highs[i - 2]) >= params.fvg_min_atr * atr:
            add_poi(l, float(highs[i - 2]), 1, 1, 1.0, i - 2)
        if strong and h < lows[i - 2] and (lows[i - 2] - h) >= params.fvg_min_atr * atr:
            add_poi(float(lows[i - 2]), h, -1, 1, 1.0, i - 2)

        if strong:
            opp_idx = -1
            for j in range(1, min(params.ob_lookback, i) + 1):
                opp_col = (closes[i - j] > opens[i - j]) if cl < o else (closes[i - j] < opens[i - j])
                if opp_col:
                    opp_idx = j
                    break
            if opp_idx > 0:
                is_scob = opp_idx == 1
                typ = 3 if is_scob else 2
                q = 1.5 if is_scob else 1.2
                add_poi(float(highs[i - opp_idx]), float(lows[i - opp_idx]), -1 if cl < o else 1, typ, q, i - opp_idx)

        if body >= params.ifc_mult * atr:
            if cl > o and cl > hi20:
                add_poi(max(cl, o), min(cl, o), 1, 5, 1.5, i - 1)
            elif cl < o and cl < lo20:
                add_poi(max(cl, o), min(cl, o), -1, 5, 1.5, i - 1)

        # 4. POI Maintenance & Flip (hub3.txt Section 6)
        for z_idx in range(len(poi_zones) - 1, -1, -1):
            z = poi_zones[z_idx]
            dead = (l <= z.bot) if z.direction == 1 else (h >= z.top)
            if dead:
                can_flip = z.poi_type in (2, 3) and not ((cl < z.bot) if z.direction == 1 else (cl > z.top))
                if can_flip:
                    span = z.top - z.bot
                    if z.direction == 1:
                        nt, nb = z.bot, z.bot - span
                    else:
                        nt, nb = z.top + span, z.top
                    z.direction = -z.direction
                    z.poi_type = 4
                    z.top = max(nt, nb)
                    z.bot = min(nt, nb)
                    z.bar_idx = i
                else:
                    poi_zones.pop(z_idx)

        # 5. Liquidity Sweeps (hub3.txt Section 7)
        swept_high = False
        swept_low = False
        swept_eq = False
        for lv in liq_levels:
            if not lv.used:
                if lv.kind == 1 and h > lv.price and cl < lv.price:
                    lv.used = True
                    swept_high = True
                    if lv.is_equal:
                        swept_eq = True
                elif lv.kind == -1 and l < lv.price and cl > lv.price:
                    lv.used = True
                    swept_low = True
                    if lv.is_equal:
                        swept_eq = True

        if i - arm_bar > 3:
            if h > hi20 and cl < hi20:
                swept_high = True
            if l < lo20 and cl > lo20:
                swept_low = True
            # Internal pullback liquidity sweep (minor swing swept with wick rejection)
            if minor_ph is not None and h > minor_ph and cl < minor_ph and (h - max(o, cl)) >= 0.45 * atr:
                swept_high = True
            if minor_pl is not None and l < minor_pl and cl > minor_pl and (min(o, cl) - l) >= 0.45 * atr:
                swept_low = True

        # IDM taken
        if minor_pl is not None and l < minor_pl:
            idm_done = True
        if minor_ph is not None and h > minor_ph:
            idm_done = True

        # 6. Arm state (hub3.txt Section 8)
        if swept_high and (last_pl is not None or minor_pl is not None):
            struct_ref = minor_pl if (minor_pl is not None and (last_pl is None or minor_pl > last_pl)) else last_pl
            if struct_ref is not None:
                arm_dir = -1
                arm_bar = i
                arm_price = h
                arm_struct = struct_ref
                arm_eq = swept_eq
                arm_swept = True
        if swept_low and (last_ph is not None or minor_ph is not None):
            struct_ref = minor_ph if (minor_ph is not None and (last_ph is None or minor_ph < last_ph)) else last_ph
            if struct_ref is not None:
                arm_dir = 1
                arm_bar = i
                arm_price = l
                arm_struct = struct_ref
                arm_eq = swept_eq
                arm_swept = True

        if arm_dir == 1 and (cl < arm_price or i - arm_bar > arm_valid_bars):
            arm_dir = 0
            arm_swept = False
        if arm_dir == -1 and (cl > arm_price or i - arm_bar > arm_valid_bars):
            arm_dir = 0
            arm_swept = False

        # 7. CHoCH + Strict High Accuracy Quality Gate (hub3.txt Section 9 + dis.zip)
        if arm_dir == 0:
            last_why_fa = "هنوز سوییپ نقدینگی معتبر روی سقف/کف کلیدی ثبت نشده است."
            continue

        if i - last_signal_bar < cooldown_bars:
            last_why_fa = f"در دوره کول‌داون پس از سیگنال قبلی ({cooldown_bars - (i - last_signal_bar)} کندل باقی‌مانده)."
            continue

        # Volatility & news spike filters
        bar_range = h - l
        if params.skip_news_spikes and bar_range > params.spike_mult * atr:
            last_why_fa = "کندل انفجاری/خبری شناسایی شد (فیلتر نوسان غیرعادی فعال)."
            continue
        if params.skip_dead_volatility and atr < params.vol_min_ratio * atr_sma50[i]:
            last_why_fa = "نوسان بازار کمتر از حد مجاز (بازار کم‌رمق / مرده)."
            continue
        if adx < params.min_adx:
            last_why_fa = f"بازار در حالت رنج است (ADX={adx:.1f} < {params.min_adx:.0f})."
            continue
        if news_blackout_active and i == n - 1:
            last_why_fa = "گارد خبری فعال است (نزدیک به انتشار خبر High Impact)."
            continue
        if use_session_tf and not in_session:
            last_why_fa = f"خارج از سشن فعال لندن/نیویورک (سشن فعلی: {ses_name})."
            continue

        sweep_ok = (not params.require_sweep) or arm_swept
        idm_ok = (not params.require_idm) or idm_done
        if not sweep_ok:
            last_why_fa = "سوییپ نقدینگی تأیید نشده است."
            continue
        if not idm_ok:
            last_why_fa = "اینداسمنت (IDM) هنوز برداشته نشده است."
            continue

        # Premium / Discount location (60-bar range)
        pd_start = max(0, i - params.pd_len + 1)
        rng_hi = float(np.max(highs[pd_start : i + 1]))
        rng_lo = float(np.min(lows[pd_start : i + 1]))
        rng_eq = (rng_hi + rng_lo) / 2.0

        # Evaluate LONG or SHORT trigger
        for candidate_dir in (1, -1):
            if arm_dir != candidate_dir:
                continue

            if candidate_dir == 1:
                body_ok = ((cl - o) >= params.disp_atr_mult * atr) if params.require_strong_choch_body else (cl > o)
                choch_ok = cl > arm_struct and body_ok
            else:
                body_ok = ((o - cl) >= params.disp_atr_mult * atr) if params.require_strong_choch_body else (cl < o)
                choch_ok = cl < arm_struct and body_ok

            if not choch_ok:
                last_why_fa = (
                    f"سوییپ انجام شد؛ در انتظار بسته‌شدن کندل قوی CHoCH "
                    f"{'بالای' if candidate_dir == 1 else 'زیر'} {arm_struct:.{digits}f}"
                )
                continue

            # HTF primary + secondary + Trend EMA alignment
            if htf_bias != candidate_dir:
                last_why_fa = "بایاس تایم‌فریم بالاتر با جهت ستاپ هم‌راستا نیست."
                continue
            if htf2_bias != 0 and htf2_bias != candidate_dir:
                last_why_fa = "تایم‌فریم مرجع دوم (EMA200 / HTF2) هم‌جهت نیست."
                continue

            poi = pick_poi(candidate_dir, arm_bar, cl, atr)
            if poi is None:
                last_why_fa = "ناحیه ورود معتبر (POI / FVG / OB) با فاصله استاندارد پیدا نشد."
                continue

            entry = (poi.top + poi.bot) / 2.0

            # Premium / Discount filter (Dealing Range):
            # In strong trends (ADX >= min_adx), Discount is <= 62% of dealing range (at least 38% retracement from high)
            # and Premium is >= 38% of dealing range (at least 38% retracement from low).
            rng_span = max(rng_hi - rng_lo, pip_size)
            long_pd_cap = rng_lo + 0.62 * rng_span
            short_pd_floor = rng_hi - 0.62 * rng_span
            in_correct_zone = (
                (entry <= long_pd_cap or arm_price <= long_pd_cap)
                if candidate_dir == 1
                else (entry >= short_pd_floor or arm_price >= short_pd_floor)
            )
            if params.use_pd_filter and not in_correct_zone:
                last_why_fa = (
                    "ستاپ خرید در ناحیه پریمیوم (گران) رد شد؛ فقط در دیسکانت مجاز است."
                    if candidate_dir == 1
                    else "ستاپ فروش در ناحیه دیسکانت (ارزان) رد شد؛ فقط در پریمیوم مجاز است."
                )
                continue

            # Stop loss with minimum floor (ATR & pips)
            min_stop_dist = max(params.min_risk_atr * atr, params.min_stop_pips * pip_size)
            if candidate_dir == 1:
                raw_sl = min(arm_price, poi.bot) - params.sl_buf_atr * atr
                risk_d = max(entry - raw_sl, min_stop_dist)
                sl = entry - risk_d
            else:
                raw_sl = max(arm_price, poi.top) + params.sl_buf_atr * atr
                risk_d = max(raw_sl - entry, min_stop_dist)
                sl = entry + risk_d

            if risk_d <= 0:
                continue

            # Confluence score (exact hub3.txt formula: max 10.0)
            score = 4.0
            score += 2.0 if htf_bias == candidate_dir else 0.0
            score += poi.quality  # 1.0 (FVG) | 1.2 (OB) | 1.5 (SCOB/IFC)
            score += 1.0 if (in_session or timeframe == "4H") else 0.0
            score += 1.0  # CHoCH confirmed
            score += 0.5 if arm_eq else 0.0
            score = min(10.0, round(score, 2))

            if score < tf_min_score:
                last_why_fa = f"امتیاز کانفلوئنس ({score:.1f}/10) کمتر از حداقل سخت‌گیرانه ({tf_min_score:.1f}) است."
                continue

            # Targets: 1.2R / 2.2R / 3.2R (NEXVORA Institutional Card) with smart liquidity snap
            min_tp1_rr = max(1.05, min(params.tp1_rr * 0.9, 1.5))
            if candidate_dir == 1:
                t1 = entry + risk_d * params.tp1_rr
                lq1 = liq_target(entry, 1, risk_d * min_tp1_rr)
                if lq1 is not None and lq1 < t1 and (lq1 - entry) >= risk_d * min_tp1_rr:
                    t1 = lq1
                t2 = entry + risk_d * params.tp2_rr
                lq2 = liq_target(t1, 1, risk_d * 0.5)
                if lq2 is not None and (lq2 - entry) > (t1 - entry) + risk_d * 0.25 and lq2 < t2 * 1.05:
                    t2 = lq2
                t3 = entry + risk_d * params.tp3_rr
                lq3 = liq_target(t2, 1, risk_d * 0.5)
                if lq3 is not None and (lq3 - entry) > (t2 - entry) + risk_d * 0.25:
                    t3 = max(t3, lq3)
            else:
                t1 = entry - risk_d * params.tp1_rr
                lq1 = liq_target(entry, -1, risk_d * min_tp1_rr)
                if lq1 is not None and lq1 > t1 and (entry - lq1) >= risk_d * min_tp1_rr:
                    t1 = lq1
                t2 = entry - risk_d * params.tp2_rr
                lq2 = liq_target(t1, -1, risk_d * 0.5)
                if lq2 is not None and (entry - lq2) > (entry - t1) + risk_d * 0.25 and lq2 > t2 * 0.95:
                    t2 = lq2
                t3 = entry - risk_d * params.tp3_rr
                lq3 = liq_target(t2, -1, risk_d * 0.5)
                if lq3 is not None and (entry - lq3) > (entry - t2) + risk_d * 0.25:
                    t3 = min(t3, lq3)

            rr1_actual = abs(t1 - entry) / risk_d
            if rr1_actual < min_tp1_rr:
                last_why_fa = f"نسبت R:R تا تارگت اول کمتر از {min_tp1_rr:.1f} است."
                continue

            mod_name = (
                "SCOB" if poi.poi_type == 3
                else "FLIP" if poi.poi_type == 4
                else "IFC" if poi.poi_type == 5
                else "SWEEP" if arm_swept
                else "CHoCH"
            )
            dir_str = "LONG" if candidate_dir == 1 else "SHORT"
            lots = _compute_lot_size(symbol, entry, sl, params.risk_pct, params.account_equity_ref)

            checklist = [
                {"key": "htf_bias", "label_fa": "هم‌جهت با بایاس HTF", "passed": True},
                {"key": "sweep", "label_fa": "سوییپ نقدینگی قبل از ورود", "passed": bool(arm_swept)},
                {"key": "choch", "label_fa": "تأیید CHoCH با بدنه قوی", "passed": True},
                {"key": "poi", "label_fa": f"ناحیه ورود باکیفیت ({mod_name})", "passed": bool(poi.quality >= 1.2)},
                {"key": "pd_loc", "label_fa": "موقعیت درست پریمیوم/دیسکانت", "passed": bool(in_correct_zone)},
                {"key": "session", "label_fa": f"سشن فعال ({ses_name})", "passed": bool(in_session or timeframe == "4H")},
                {"key": "idm", "label_fa": "برداشته شدن اینداسمنت (IDM)", "passed": bool(idm_done)},
                {"key": "adx_regime", "label_fa": f"عدم رنج بازار (ADX={adx:.1f})", "passed": bool(adx >= params.min_adx)},
                {"key": "rr_check", "label_fa": f"نسبت پاداش/ریسک TP1 ({rr1_actual:.1f}R)", "passed": bool(rr1_actual >= min_tp1_rr)},
                {"key": "eq_liq", "label_fa": "سوییپ نقدینگی برابر (EQH/EQL)", "passed": bool(arm_eq)},
            ]

            rationale = (
                f"ستاپ {dir_str} با ماژول {mod_name} روی {meta['display']} ({tf_meta['label_fa']}): "
                f"پس از سوییپ نقدینگی و تأیید شکست ساختار (CHoCH) هم‌راستا با بایاس تایم‌فریم بالاتر، "
                f"سفارش لیمیت روی میانه POI ثبت شد. امتیاز کانفلوئنس {score:.1f}/10 (گرید {_score_to_grade(score)}) "
                f"و ADX={adx:.1f}. مدیریت پله‌ای: انتقال SL به سر‌به‌سر در ۷۰٪ مسیر تا TP1، "
                f"۵۰٪ خروج در TP1 ({params.tp1_rr:.1f}R)، ۳۰٪ در TP2 ({params.tp2_rr:.1f}R) + انتقال SL به TP1، و ۲۰٪ تا TP3 ({params.tp3_rr:.1f}R)."
            )

            sig = TradeSetupSignal(
                bar_idx=int(i),
                timestamp=c.timestamp,
                symbol=symbol,
                timeframe=timeframe,
                risk_tier=risk_tier,
                direction=dir_str,
                entry_module=mod_name,
                entry_price=round(float(entry), digits),
                sl=round(float(sl), digits),
                tp1=round(float(t1), digits),
                tp2=round(float(t2), digits),
                tp3=round(float(t3), digits),
                tp1_exit_pct=float(params.tp1_exit_pct),
                tp2_exit_pct=float(params.tp2_exit_pct),
                tp3_exit_pct=round(float(max(0.0, 100.0 - params.tp1_exit_pct - params.tp2_exit_pct)), 1),
                confluence_score=round(float(score), 2),
                grade=_score_to_grade(float(score)),
                htf_bias="BULLISH" if htf_bias == 1 else "BEARISH" if htf_bias == -1 else "NEUTRAL",
                session_name=ses_name,
                position_size_lots=round(float(lots), 2),
                checklist=checklist,
                rationale_fa=rationale,
                bars_valid=int(arm_valid_bars),
            )
            signals.append(sig)
            last_signal_bar = i
            arm_dir = 0
            arm_swept = False
            idm_done = False
            last_why_fa = f"ستاپ معتبر {dir_str} تأیید شد (امتیاز {score:.1f}/10)."

    # Compute final live snapshot
    latest_ses, _, _, _ = classify_session_ny(candles[-1].timestamp)
    final_bias_int = htf1_bias_global if htf1_bias_global != 0 else (1 if closes[-1] > ema_htf_proxy[-1] else -1)
    final_bias_txt = "BULLISH" if final_bias_int == 1 else "BEARISH" if final_bias_int == -1 else "NEUTRAL"

    latest_sig = signals[-1] if (signals and (n - 1 - signals[-1].bar_idx) <= 6) else None
    if latest_sig is not None:
        state_str = "SETUP_READY"
        readiness = 100
    elif arm_dir != 0:
        state_str = "ARMED"
        readiness = 70
    else:
        state_str = "FLAT"
        readiness = 35 if adx_arr[-1] >= params.min_adx else 15

    return EngineEvaluation(
        symbol=symbol,
        timeframe=timeframe,
        risk_tier=risk_tier,
        state=state_str,
        htf_bias=final_bias_txt,
        session_name=latest_ses,
        adx_value=round(float(adx_arr[-1]), 1),
        atr_value=round(float(atr_arr[-1]), digits),
        readiness_pct=readiness,
        why_no_trade_fa=last_why_fa,
        active_poi_count=len(poi_zones),
        active_liq_count=len([lv for lv in liq_levels if not lv.used]),
        latest_signal=latest_sig,
        historical_signals=signals,
    )
