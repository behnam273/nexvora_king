from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from app.config import ALLOWED_SYMBOLS, ALLOWED_TIMEFRAMES, TIMEFRAME_META
from app.engine.market_data import Candle, get_market_series
from app.engine.trading_hub3 import HighAccuracyParams, TradeSetupSignal, run_trading_hub3_engine
from app.models import BacktestQualification, EngineConfig, utcnow


@dataclass
class SimulatedTradeResult:
    signal: TradeSetupSignal
    filled: bool
    outcome: str      # WIN | LOSS | BE | EXPIRED
    realized_r: float
    tp1_hit: bool
    tp2_hit: bool
    tp3_hit: bool
    exit_bar_idx: int


def simulate_signal_lifecycle(
    sig: TradeSetupSignal,
    candles: List[Candle],
    commission_r: float = 0.04,
) -> SimulatedTradeResult:
    """
    Deterministic bar-by-bar execution simulator matching hub3.txt partial exit & BE rules:
    - Limit order waits up to `bars_valid` bars for fill; invalidated if SL breached before fill.
    - Once filled: conservative intra-bar order (checks SL before TP if both touched on same bar).
    - TP1 hit: closes tp1_exit_pct (50%) and moves SL to breakeven (entry_price).
    - TP2 hit: closes tp2_exit_pct (30%) and moves SL to TP1.
    - TP3 hit: closes remaining tp3_exit_pct (20%).
    """
    n = len(candles)
    is_long = sig.direction == "LONG"
    risk_d = abs(sig.entry_price - sig.sl)
    if risk_d <= 0:
        return SimulatedTradeResult(sig, False, "EXPIRED", 0.0, False, False, False, sig.bar_idx)

    filled = False
    fill_bar = -1
    max_wait_bar = min(n - 1, sig.bar_idx + sig.bars_valid)

    for b in range(sig.bar_idx + 1, max_wait_bar + 1):
        c = candles[b]
        # If invalidated before fill
        if is_long and c.close < sig.sl:
            return SimulatedTradeResult(sig, False, "EXPIRED", 0.0, False, False, False, b)
        if not is_long and c.close > sig.sl:
            return SimulatedTradeResult(sig, False, "EXPIRED", 0.0, False, False, False, b)
        # Check limit touch
        if is_long and c.low <= sig.entry_price <= c.high:
            filled = True
            fill_bar = b
            break
        if not is_long and c.low <= sig.entry_price <= c.high:
            filled = True
            fill_bar = b
            break

    if not filled:
        return SimulatedTradeResult(sig, False, "EXPIRED", 0.0, False, False, False, max_wait_bar)

    cur_sl = sig.sl
    rem = 1.0
    p1 = sig.tp1_exit_pct / 100.0
    p2 = sig.tp2_exit_pct / 100.0
    realized_r = 0.0
    tp1_hit = tp2_hit = tp3_hit = False

    rr1 = abs(sig.tp1 - sig.entry_price) / risk_d
    rr2 = abs(sig.tp2 - sig.entry_price) / risk_d
    rr3 = abs(sig.tp3 - sig.entry_price) / risk_d
    early_be_px = sig.entry_price + 0.70 * (sig.tp1 - sig.entry_price)
    early_be_done = False

    for b in range(fill_bar + 1, n):
        c = candles[b]
        sl_hit = (c.low <= cur_sl) if is_long else (c.high >= cur_sl)
        if sl_hit:
            sl_r = ((cur_sl - sig.entry_price) / risk_d) if is_long else ((sig.entry_price - cur_sl) / risk_d)
            realized_r += rem * sl_r
            realized_r -= commission_r
            outcome = "WIN" if realized_r > 0.05 else ("BE" if abs(realized_r) <= 0.05 else "LOSS")
            return SimulatedTradeResult(sig, True, outcome, round(realized_r, 3), tp1_hit, tp2_hit, tp3_hit, b)

        if not tp1_hit and ((c.high >= sig.tp1) if is_long else (c.low <= sig.tp1)):
            tp1_hit = True
            early_be_done = True
            take = min(rem, p1)
            realized_r += take * rr1
            rem -= take
            cur_sl = sig.entry_price  # Move SL to Break-Even!
            if rem <= 1e-6:
                return SimulatedTradeResult(sig, True, "WIN", round(realized_r - commission_r, 3), True, False, False, b)

        # Early Break-Even at 70% of entry-to-TP1 (matches Official Signal Card rule)
        if not tp1_hit and not early_be_done:
            reached_early_be = (c.high >= early_be_px) if is_long else (c.low <= early_be_px)
            if reached_early_be:
                early_be_done = True
                cur_sl = sig.entry_price

        if tp1_hit and not tp2_hit and ((c.high >= sig.tp2) if is_long else (c.low <= sig.tp2)):
            tp2_hit = True
            take = min(rem, p2)
            realized_r += take * rr2
            rem -= take
            cur_sl = sig.tp1  # Lock profit at TP1!
            if rem <= 1e-6:
                return SimulatedTradeResult(sig, True, "WIN", round(realized_r - commission_r, 3), True, True, False, b)

        if tp2_hit and not tp3_hit and ((c.high >= sig.tp3) if is_long else (c.low <= sig.tp3)):
            tp3_hit = True
            realized_r += rem * rr3
            rem = 0.0
            return SimulatedTradeResult(sig, True, "WIN", round(realized_r - commission_r, 3), True, True, True, b)

    # Still open at end of historical window -> mark-to-market unrealized close for backtest evaluation
    last_close = candles[-1].close
    mtm_r = ((last_close - sig.entry_price) / risk_d) if is_long else ((sig.entry_price - last_close) / risk_d)
    total_r = realized_r + rem * mtm_r - commission_r
    outcome = "WIN" if total_r > 0.05 else ("BE" if abs(total_r) <= 0.05 else "LOSS")
    return SimulatedTradeResult(sig, True, outcome, round(total_r, 3), tp1_hit, tp2_hit, tp3_hit, n - 1)


def config_to_params(cfg: Optional[EngineConfig]) -> HighAccuracyParams:
    if cfg is None:
        return HighAccuracyParams()
    return HighAccuracyParams(
        tp1_rr=cfg.tp1_rr,
        tp2_rr=cfg.tp2_rr,
        tp3_rr=cfg.tp3_rr,
        tp1_exit_pct=cfg.tp1_exit_pct,
        tp2_exit_pct=cfg.tp2_exit_pct,
        min_score_4h=cfg.min_score_4h,
        min_score_15m=cfg.min_score_15m,
        min_score_5m=cfg.min_score_5m,
        min_adx=cfg.min_adx,
        trend_ema_len=cfg.trend_ema_len,
        require_sweep=cfg.require_sweep,
        require_idm=cfg.require_idm,
        require_strong_choch_body=cfg.require_strong_choch_body,
        use_pd_filter=cfg.use_pd_filter,
        use_session_filter=cfg.use_session_filter,
        skip_dead_volatility=cfg.skip_dead_volatility,
        skip_news_spikes=cfg.skip_news_spikes,
    )


def evaluate_pair_backtest(
    symbol: str,
    timeframe: str,
    db: Session,
    cfg: Optional[EngineConfig] = None,
) -> Tuple[BacktestQualification, List[SimulatedTradeResult]]:
    params = config_to_params(cfg)
    tf_meta = TIMEFRAME_META[timeframe]
    min_wr = cfg.min_backtest_winrate if cfg else 55.0
    min_pf = cfg.min_backtest_pf if cfg else 1.4
    min_trades = cfg.min_backtest_trades if cfg else 3

    series = get_market_series(symbol, timeframe, limit=420, db=db)
    htf1 = get_market_series(symbol, tf_meta["htf_primary"], limit=200, db=db)
    htf2 = get_market_series(symbol, tf_meta["htf_secondary"], limit=200, db=db) if tf_meta["htf_secondary"] != tf_meta["htf_primary"] else htf1

    evaluation = run_trading_hub3_engine(
        symbol=symbol,
        timeframe=timeframe,
        candles=series.candles,
        params=params,
        htf1_candles=htf1.candles,
        htf2_candles=htf2.candles,
    )

    # Simulate non-overlapping trades (pyramiding = 0, matching hub3.txt)
    results: List[SimulatedTradeResult] = []
    busy_until = -1
    for sig in evaluation.historical_signals:
        if sig.bar_idx <= busy_until:
            continue
        sim = simulate_signal_lifecycle(sig, series.candles)
        if sim.filled:
            results.append(sim)
            busy_until = sim.exit_bar_idx

    total = len(results)
    wins = sum(1 for r in results if r.outcome == "WIN")
    losses = sum(1 for r in results if r.outcome == "LOSS")
    bes = sum(1 for r in results if r.outcome == "BE")

    # Documented Win Rate formula: Winning Trades / Eligible Closed Trades * 100
    win_rate = round((wins / total) * 100.0, 2) if total > 0 else 0.0
    gross_profit_r = sum(r.realized_r for r in results if r.realized_r > 0)
    gross_loss_r = abs(sum(r.realized_r for r in results if r.realized_r < 0))
    if gross_loss_r > 0:
        pf = round(gross_profit_r / gross_loss_r, 2)
    elif gross_profit_r > 0:
        pf = 9.99
    else:
        pf = 0.0

    avg_r = round(sum(r.realized_r for r in results) / total, 3) if total > 0 else 0.0
    expectancy_r = avg_r

    # Max drawdown on 1% risk per trade equity curve
    eq = 100.0
    peak = 100.0
    max_dd = 0.0
    for r in results:
        eq *= (1.0 + (r.realized_r * 0.01))
        if eq > peak:
            peak = eq
        dd = (peak - eq) / peak * 100.0 if peak > 0 else 0.0
        max_dd = max(max_dd, dd)

    eligible = (total >= min_trades) and (win_rate >= min_wr) and (pf >= min_pf)
    if eligible:
        reason_fa = (
            f"تأییدشده برای کانال تلگرام — وین‌ریت {win_rate:.1f}% (≥ {min_wr:.0f}%) "
            f"و Profit Factor برابر {pf:.2f} روی {total} معامله معتبر."
        )
    elif total < min_trades:
        reason_fa = f"رد موقت: تعداد معاملات بک‌تست کافی نیست ({total} < {min_trades})."
    elif win_rate < min_wr:
        reason_fa = f"رد توسط فیلتر وین‌ریت: {win_rate:.1f}% کمتر از آستانه سخت‌گیرانه {min_wr:.0f}% است."
    else:
        reason_fa = f"رد توسط فیلتر Profit Factor: {pf:.2f} کمتر از حداقل {min_pf:.2f} است."

    row = (
        db.query(BacktestQualification)
        .filter(BacktestQualification.symbol == symbol, BacktestQualification.timeframe == timeframe)
        .first()
    )
    if not row:
        row = BacktestQualification(symbol=symbol, timeframe=timeframe, risk_tier=tf_meta["risk_tier"])
        db.add(row)

    row.risk_tier = tf_meta["risk_tier"]
    row.eligible_for_telegram = eligible
    row.reason_fa = reason_fa
    row.total_trades = total
    row.winning_trades = wins
    row.losing_trades = losses
    row.breakeven_trades = bes
    row.win_rate = win_rate
    row.profit_factor = pf
    row.expectancy_r = expectancy_r
    row.max_drawdown_pct = round(max_dd, 2)
    row.avg_r = avg_r
    row.window_bars = len(series.candles)
    row.data_source = series.source
    row.is_demo_data = series.is_demo_data
    row.evaluated_at = utcnow()
    db.commit()
    db.refresh(row)
    return row, results


def refresh_all_qualifications(db: Session, cfg: Optional[EngineConfig] = None) -> List[BacktestQualification]:
    rows: List[BacktestQualification] = []
    for sym in ALLOWED_SYMBOLS:
        for tf in ALLOWED_TIMEFRAMES:
            q, _ = evaluate_pair_backtest(sym, tf, db, cfg)
            rows.append(q)
    return rows
