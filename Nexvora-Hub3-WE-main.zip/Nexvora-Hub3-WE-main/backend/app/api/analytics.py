from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.config import ALLOWED_SYMBOLS, ALLOWED_TIMEFRAMES
from app.database import get_db
from app.models import BacktestQualification, User
from app.schemas import BacktestQualificationOut
from app.security import get_current_user
from app.services.analytics import compute_performance_analytics

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])


@router.get("/performance")
def get_performance(
    days: Optional[int] = Query(default=None, ge=1, le=365),
    symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
    include_be: bool = True,
    _user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    sym = symbol if symbol in ALLOWED_SYMBOLS else None
    tf = timeframe if timeframe in ALLOWED_TIMEFRAMES else None
    return compute_performance_analytics(
        db=db,
        days=days,
        symbol=sym,
        timeframe=tf,
        include_be_in_winrate_denominator=include_be,
    )


@router.get("/qualifications", response_model=List[BacktestQualificationOut])
def get_backtest_qualifications(
    _user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rows = (
        db.query(BacktestQualification)
        .order_by(BacktestQualification.eligible_for_telegram.desc(), BacktestQualification.win_rate.desc())
        .all()
    )
    return [BacktestQualificationOut.model_validate(r) for r in rows]
